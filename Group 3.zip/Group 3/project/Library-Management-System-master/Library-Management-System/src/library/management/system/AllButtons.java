package library.management.system;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AllButtons extends JFrame{

    public void CreateNewButtons(JButton bt){
       // bt = new JButton();
        bt.setFocusPainted(false);
        bt.setBorderPainted(false);
        bt.setBackground(new Color(0,125,182));
        bt.setForeground(Color.WHITE);
        bt.addMouseListener(new MouseAdapter() {
            Color color = bt.getBackground();
            public void mouseEntered(MouseEvent me) {
                color = bt.getBackground();
                bt.setBackground(new Color(0,100,200));
            }
            public void mouseExited(MouseEvent me) {
                bt.setBackground(color);
            }
        });
    }

}
