package library.management.system;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.*;

public class aboutUs extends JFrame implements ActionListener {

	JLabel l;
	JButton b;
	AllButtons btn = new AllButtons();

        public static void main(String[] args) {
            new aboutUs().setVisible(true);			
	}
    
        public aboutUs() {
            
            super("Team");
            setSize(940,788);
            setLayout(null);
            setLocation(300,100);
            setResizable(false);

            l = new JLabel("");
            b = new JButton("BACK");
            btn.CreateNewButtons(b);


            ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("library/management/system/icons/Team.png"));
            Image i3 = i1.getImage().getScaledInstance(940, 788,Image.SCALE_DEFAULT);
            ImageIcon i2 = new ImageIcon(i3);
            l = new JLabel(i2);

            b.setBounds(695,680,200,60);
            l.setBounds(0, 0, 940, 788);

            l.add(b);
            add(l);

            b.addActionListener(this);
        }

    public void actionPerformed(ActionEvent ae){
        new Home().setVisible(true);
        this.setVisible(false);
        this.dispose();


    }


    }

